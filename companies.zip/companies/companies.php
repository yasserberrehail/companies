<?php
/**
 * Module Name: companies
 * Description: A module to manage all companies for each country
 * Author: hawala.pro
 * Version: 1.0.0
 */

// Resto del código del módulo...
